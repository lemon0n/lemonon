# 中国 ETF 量化研究台 · 系统全景与实现说明

> 面向外部评审的单文件说明。目标：不看仓库也能回答三个问题——
> **① 为什么这样排顺序（先什么、再什么、为什么不能倒）**；
> **② 每一块具体怎么算、代码怎么写、失败怎么办**；
> **③ 分析与解释用的提示词到底长什么样、怎么防幻觉**。
>
> 版本 2026-11-24 · Python 约 11,000 行 / 前端 `app.js` 3,902 行 / 测试 174 项
> 每日入口：`bash scripts/daily.sh` · 逐块速查：`docs/页面区块对照.md`

---

## 目录

- 第一部分 设计原理：为什么是这个结构
  - 1. 问题定义与三条公理
  - 2. 为什么顺序是「数据 → 环境 → 结构 → 组合 → 执行 → 解释」
  - 3. 一次运行的完整因果链（每步：为什么现在 / 依赖 / 产出 / 失败）
  - 4. 页面为什么这样排（阅读顺序 vs 计算顺序）
- 第二部分 实现细节（逐模块：输入 / 算法 / 边界）
  - 5. 配置与观察池
  - 6. 取数层（含每个源、缓存、降级、未收盘剔除）
  - 7. 数据质量与状态机
  - 8. 指标层（列级公式与代码）
  - 9. 规则卡（10 条规则 + 4 条覆盖，逐条真值表）
  - 10. 市场状态与相对强弱
  - 11. 组合层（目标权重：逐步推导）
  - 12. 执行层（价位、差额、订单、六条边界）
  - 13. 数据包与不变量（20+ 条校验逐条列）
- 第三部分 页面实现
  - 14. 单文件生成与 DASHBOARD 结构
  - 15. 前端计算细节（解密、盈亏、清洗、补算、评分、概率、缠论）
  - 16. 页面逐块：内容 + 代码 + 数据来源
  - 17. 为什么个股卡是九块、为什么这个顺序
- 第四部分 分析与提示词
  - 18. 两类 LLM 任务与职责边界
  - 19. 今日点评提示词（全文 + 五段生成规则 + 校验）
  - 20. 消息面解读提示词（全文模板）
  - 21. 持仓深度分析提示词（归档工作流 B 的核心条款）
  - 22. 上游 skills 的提示词结构与借用点
  - 23. 防幻觉四道闸门与回退路径
- 第五部分 质量、边界与演进
  - 24. 测试与门禁
  - 25. 已实现 / 未实现矩阵
  - 26. 关键取舍与代价
  - 27. 风险与下一步
- 附录 A 常用命令 · B 字段速查 · C 函数索引 · D 术语

---

# 第一部分 设计原理：为什么是这个结构

## 1. 问题定义与三条公理

### 1.1 这个系统在解决什么问题

个人用 ETF 做中线波段，每天要回答四个问题：

1. 今天市场处于什么状态，总仓位该给多少？
2. 手里的几只，各自该留多少、减多少？
3. 具体怎么下单：方向、份数、挂单价、费用？
4. 什么情况下我判断错了、要改？

难点不在「算指标」，而在**四个答案必须互相一致**：
如果环境说「下行、上限 35%」，明细表却因为技术面强而建议加仓，用户就不知道该信谁。

### 1.2 旧版的病：四套判断同时在跑

| 位置 | 它当时在说什么 | 冲突点 |
|---|---|---|
| 规则卡 methodology | 这只触发减仓 | 不知道用户有没有执行 |
| 目标仓位表 plan_v3 | 这只该占 8.9% | 与规则动作不保证一致 |
| 执行后估算 | 执行完还剩多少仓 | 自己算一遍，与表里份数对不上 |
| 持仓分析（技术） | 日线转强、缠论买点 | 与上面的减仓正好相反 |

修复不是「把文案写得更客气」，而是**从结构上只保留一个出口**。

### 1.3 三条公理

| 公理 | 含义 | 代码体现 |
|---|---|---|
| A1 可复核 | 任一结论的数字都能在同一页找到同一口径来源 | 点评每句带数字；`refs` 指字段路径；明细表与个股卡同读 `RS_PLAN` |
| A2 可降级 | 缺数据时明说缺，不估算、不硬凑 | `ABSTAIN` ≠ 持有；缺价/缺成本/缺昨收各自「—」；样本 <30 写「样本不足」 |
| A3 单一出口 | 动作只由「目标仓位表 → 差额」派生 | `planActionOf()` 只有一个实现；规则卡只做闸门与最早时点 |

这三条决定了后面所有顺序。

---

## 2. 为什么顺序是「数据 → 环境 → 结构 → 组合 → 执行 → 解释」

### 2.1 因果依赖图

```
规则卡（配置，先校验）
   │
   ▼
① 数据闸门 ── 不通过 ──▶ 只给事实，不给动作（终止决策链）
   │
   ▼
② 环境层：基准日线 → 市场状态 → 总仓位上限
   │            （没有它，后面不知道「总共允许多少」）
   ▼
③ 结构层：个股月/周/日 → 评分 → 单只上限
   │            （没有它，不知道「这只最多给多少」）
   ▼
④ 组合层：总额度 × 评分系数 × 波动 → 归一 → 单只目标权重
   │            （前三层的额度在这里合成）
   ▼
⑤ 执行层：目标 − 现仓 = 差额 → 确认条件 → 动作 → 挂单/份数/费用
   │            （没有目标就没有差额，没有差额就没有订单）
   ▼
⑥ 解释层：点评 / 个股卡 / 洞察
                （只能引用 ①–⑤ 的结论，不能自创）
```

### 2.2 每一步「为什么不能倒」

| 顺序 | 如果倒过来会怎样 |
|---|---|
| 先环境、后个股 | 先有总上限，个股评分再高也不能突破；倒过来会先算出「想买多少」，再被环境砍，用户看到两套数 |
| 先质量、后指标 | 不先判数据是否可用，就会用陈旧/合成数据算出「漂亮」的指标并出单 |
| 先目标、后动作 | 动作若先由规则决定，目标就沦为装饰，回到「四套判断」 |
| 先动作、后订单 | 订单必须由目标份额派生；否则份数与目标对不上，执行后仓位不平 |
| 先结论、后解释 | 解释若先写，会反过来影响结论（LLM 常见问题），无法复核 |
| 先主数据、后派生 | 快照/情绪若先算，会污染基准趋势这类可由真实日线算出的结论 |

### 2.3 三层额度的「只能收紧」规则

```
L1 环境：总上限 = 85 / 65 / 35 / 25（波动抬升再降 10）
   ↓ 只能往下压
L2 板块：单板块上限 = S25 / A20 / B10 / C5 / D0
   ↓ 只能往下压
L3 个股：单只上限 = S25 / A20 / B10 / C5 / D3
   ↓ 取三者最小值
目标权重 = min(单只上限, 板块压缩后的份额, 总上限分摊)
```

任何一层都不能把上层给的额度放大。这条写死在 `plan_v3.build()` 与前端 `rsPlanRows()` 的板块压缩里。

---

## 3. 一次运行的完整因果链

### 3.1 编排入口

```
scripts/daily.sh
  → scripts/run_update.py --json --push
      → pipeline.run(use_live=True)
```

### 3.2 `pipeline.run()` 的 14 步（逐步说明）

| # | 代码 | 为什么现在做 | 依赖 | 产出 | 失败策略 |
|---|---|---|---|---|---|
| 1 | `cfg = config.cfg()` | 所有阈值先就位；配置错误要在启动暴露 | — | 配置字典 | 抛错退出 |
| 2 | `uni = universe.load()` | 决定取哪些代码、各自基准 | 配置 | 观察池 4 只 | 抛错 |
| 3 | `loader.reset(live_mode)` | 清空上次运行的缓存与来源标记，避免跨次污染 | — | 干净状态 | — |
| 4 | `now = now_tz()` | 决定「今天」与时段口径 | 配置时区 | 带时区时间 | 回退 UTC+8 |
| 5 | `market = loader.market()` | 人工快照：情绪、快讯、宏观 | 快照文件 | dict | 文件缺失则启动失败 |
| 6 | `sectors = loader.sector_flow()` | 板块成交占比，供组合层与热度 | 实时/快照 | DataFrame | 降级快照 |
| 7 | `spot_df = loader.spot()` | 最新价与 IOPV；每条腿要用 | 实时/快照 | DataFrame | 降级快照 |
| 8 | `wl = watchlist.load(cfg, spot)` | 把观察池与实时价对齐 | 2 & 7 | rows + skipped | 缺价进 skipped |
| 9 | `bench = loader.index_daily('000300')` | 市场状态只能由基准日线算 | 实时/快照 | DataFrame | 记 fallback，bench=None |
| 10 | `regime = market_regime.compute(bench, market, cfg)` | 先定总仓位上限，后面所有额度从这里派生 | 9 & 5 | 状态 + 区间 + 位置 + 缺口 | 基准不足 → 「未知」、区间 null |
| 11 | `idx_rows = loader.indices()` | 页面顶部指数点位（失败保留快照旧值） | 实时 | list | 保留快照 |
| 12 | 逐腿：`loader.daily(code)` → `index_daily(bench_code)` | 没有日线就无法算特征与质量 | 2 | bars | 失败进 skipped |
| 13 | `src = loader.source_report()` | **必须等所有通道都取过** 才能判定哪条回落、是否 synthetic | 5–12 | 来源报告 | — |
| 14 | 逐腿：`quality.check_bars` → `analyze` → `relative_strength` → `methodology.decide` | 质量先行；没有质量结论，指标再准也不能出动作 | 12 & 13 | 腿结果 | 单腿失败进 skipped |

> 第 13 步的位置是关键：早期版本在取 index_daily 之前就判 synthetic，
> 导致「基准还没取就被判成合成」。现在的顺序保证判定基于完整信息。

### 3.3 之后五步（为什么在循环之后）

| # | 代码 | 为什么在循环之后 |
|---|---|---|
| 15 | `status = merge_status(...)` | 必须等所有腿的质量结果，才能取最差状态 |
| 16 | 组装 `meta`（data_date / run_date / run_id） | `data_date` 取各腿最后交易日最大值，只能循环后算 |
| 17 | `packet.build()` + `validate_packet()` | 所有字段齐了才能跑不变量；校验失败 → 状态 ERROR、不发布 |
| 18 | `plan_v3.build(bars_by_code, bench, regime)` | 需要全部 bars 与 regime；与 `decide` 独立（规则只管闸门） |
| 19 | `webgen.build_data()` + `render()` | 页面只读最终结果，不能在中途渲染半成品 |
| 20 | `packet.write()`（归档 + 发布副本） | 与页面同一次运行，保证 `run_id` 同源 |
| 21 | `run_update`：`verify → git add → commit → push` | 先验证同源，再提交；推送失败走 rebase 自愈 |

### 3.4 为什么规则求值（decide）在计划（plan）之前

看起来「先有目标才好决定动作」，但代码里 `decide` 先跑。原因：

- `decide` 只依赖**单腿特征 + 数据状态**，不依赖组合；
- 它输出的是「这只现在是不是触发风险退出/减仓/加仓」的**规则结论**；
- `plan_v3` 输出「这只应该占多少」，两者独立计算；
- 页面最终动作**只取 plan**；规则结论用于：①数据闸门 ②`packet.legs[].action` 的公开记录 ③个股卡解释。

如果让 plan 依赖 decide，规则卡就会重新变成「第二套动作来源」，违背 A3。

### 3.5 为什么状态合并要用「最差」

`merge_status` 优先级 `ERROR > ABSTAIN > DEMO > DEGRADED > OK`。
组合里只要有一只腿数据不可用，整体就不能宣称 OK——否则用户会以为所有结论都可靠。

### 3.6 每日脚本的六步与顺序理由

| 步 | 做什么 | 为什么在这个位置 |
|---|---|---|
| 1 | `git pull --rebase --autostash` | 先同步，避免产物基于旧代码 |
| 2 | 找 Python、装依赖 | 后面所有脚本都依赖 |
| 3 | （可选）持仓分析 | 独立于市场页；失败不阻断 |
| 4 | `fetch_market_snapshot.py` | 必须在 `run_update` 之前：页面要读 `market.json` |
| 5 | `fetch_national_team.py` | 同上：页面要读 `national_team.json` |
| 6 | `run_update.py --json --push` | 最后生成 + 校验 + 推送；前面任何一步失败都还能用旧快照 |

`fetch_market_snapshot.py` 内部还有一条顺序规则：
**只有 breadth 抓取成功才刷新 `market.as_of`**。因为情绪/快讯/政策仍是人工快照，
外盘或折溢价单独成功就改总时间戳，会把两周前的新闻说成「今天」。

---

## 4. 页面为什么这样排

### 4.1 阅读顺序 ≠ 计算顺序

计算顺序是依赖驱动（数据→环境→结构→组合→执行）；
阅读顺序是决策驱动：**先给结论，再给证据，最后给远景**。

```
一、持仓概况   我有多少钱、今天动什么、多少份什么价   ← 一屏内可执行
二、持仓分析   市场什么环境、组合跟不跟得上、每只为什么  ← 需要深读
三、市场洞察   接下来可能怎么走、还能看什么方向        ← 做下周打算
```

顺序不可倒：先讲理由再给结论，用户会自己在心里先形成一个动作，然后与表格冲突。

### 4.2 p1（市场概况）的内部顺序

| 顺序 | 区块 | 为什么在这 |
|---|---|---|
| 1 | 快照日提示 | 最先告诉读者「哪些数据不是今天的」，避免误读 |
| 2 | 四卡（成交/情绪/仓位区间/依据） | 一屏给出全局状态 |
| 3 | 指数与均线 | 状态的原始证据 |
| 4 | 状态与情绪条目 | 解释状态怎么来的 |
| 5 | 阶段 → 仓位 → 我的持仓 | 把公开状态与个人仓位接上（唯一联动点） |
| 6 | 板块概况 + 热力图 | 从大盘下沉到行业 |
| 7 | 国家队（最新一期） | 背景资金，只作参考 |
| 8 | 行业成交额与占比 | 热力图的表格版（可查数） |
| 9 | 轮动与主线 + 涨跌分布 | 结构结论 |
| 10 | 宏观四块 | 更慢的变量，放后面 |
| 11 | 政策与消息 | 当日扰动，最后 |

理由：从「最快变化」到「最慢变量」，从「结论」到「背景」。
用户如果只看前四块，已经能做仓位判断。

### 4.3 p5 的内部顺序

```
一、概况
   ① 四个数字        先知道钱
   ② 今日点评        再看今天做什么、为什么
   ③ 明细表          最后给可直接抄的下单信息
二、分析
   1. 市场环境       约束层：能不能进攻
   2. 组合情况       结构层：方向对不对、额度怎么分
   3. 个股分析       执行层：这一只怎么下手
三、洞察
   定性 / 赔率 / 情绪 / 情景 / 复盘 / 候选
```

为什么点评在表之前：点评回答「今天该不该动」，表回答「怎么动」。
先动后说原因，会让用户跳过大意直接抄单。

为什么个股在最后：它依赖前两层给的额度与板块结论；放前面会诱导「先看个股再找理由」。

### 4.4 渲染顺序（运行时）

```
D = window.DASHBOARD
  → render()                先出 p1 + p5/p7 骨架
  → autoUnlock()            有会话口令则解密
  → 解锁 → applyHold → render()（重绘，带持仓）
  → page5() 末尾 setTimeout(rsInit, 0)
       ① rsRenderBrief（先用已有数据出一版点评）
       ② rsRenderSector / rsRenderMarket / rsRenderDetail（骨架 + 占位）
       ③ 并行 fetchBars + rsFetchWeekly（每只持仓）
       ④ 全部回来 → rsAfterBars()
            → rsRefreshPlanTable()（重算目标与订单）
            → 再渲染点评、组合、个股、概率、候选、复盘
```

为什么允许「先渲染一版、再刷新」：

- 持仓解密是本地异步操作，日线是跨域 JSONP，都不能阻塞首屏；
- 首屏必须能看，否则用户以为坏了；
- 数据到达后统一重算，保证「表格、点评、个股卡」来自同一份 `RS_PLAN`。

风险与对策：如果只刷新一部分，会出现「表说减仓、点评说持有」。
所以 `rsAfterBars()` 里**先 `rsRefreshPlanTable()`，再渲染所有引用它的块**。

---

# 第二部分 实现细节

## 5. 配置与观察池

### 5.1 四份配置各管什么

| 文件 | 管什么 | 谁读 |
|---|---|---|
| `methodology.yaml` | 规则卡：动作、等级、谓词、规则、覆盖、文案模板 | `methodology.py` |
| `risk.yaml` | 状态→仓位区间、结构目标、硬约束、费用、风险桶 | `market_regime` / `plan_v3` / `packet` |
| `strategy.yaml` | 均线周期、量比阈值、突破四条、回测参数 | `features.py` / 回测 |
| `universe.yaml` | 观察池 4 只、基准映射、报价精度、lot_size | `universe.py` |

### 5.2 配置加载

`config.cfg()` 每次读 YAML 并缓存；`methodology.load()` 额外跑 `validate()`：

```python
def validate(m):
    allow = set(m['predicates'])                 # 谓词白名单
    for r in m['rules']:
        assert r['id'] not in seen               # 重复 ID
        assert r['action'] in VALID_ACTIONS      # CLEAR/TRIM/ADD/HOLD/WATCH
        assert r['level'] in VALID_LEVELS        # A/B/C/D
        assert all(k in allow for k in r['when'])  # 未注册谓词
        assert isinstance(r['priority'], int)
```

任何一条不满足 → 启动即抛 `RuleConfigError`。
**不允许**用 `always → HOLD` 兜底掩盖拼写错误。

### 5.3 观察池与基准映射

```yaml
etfs:
  - {code: '510300', name: 沪深300ETF, category: 宽基, benchmark: '000300'}
  - {code: '510500', name: 中证500ETF, category: 宽基, benchmark: '000905'}
  - {code: '588000', name: 科创50ETF,  category: 宽基, benchmark: '000688'}
  - {code: '159915', name: 创业板ETF,  category: 宽基, benchmark: '399006'}
```

`universe.benchmark(code, uni)`：先看池内显式映射，再按代码段推断；查不到返回 None（相对强弱标未知）。

---

## 6. 取数层

### 6.1 统一入口与三种来源

每个取数函数都走同一模式：

```python
def daily(code, live_=None):
    if code in _CACHE['daily']: return _CACHE['daily'][code].copy()
    if use_live:
        df = live.fetch_daily(code)          # 东财 → 腾讯 → 新浪
        if df is not None:
            df = validate_bars(df, code)     # 列齐 / 可解析 / ≥30 根
            df.to_csv(cache_path)            # 落缓存
            STATE['daily'][code] = 'live'
            return df
    STATE['daily'][code] = 'snapshot'        # 降级
    note_fallback('%s 日线降级离线合成快照' % code)
    return snapshot.daily(code)
```

来源只有两种语义：

| 标记 | 含义 | 上层必须做什么 |
|---|---|---|
| `live` | 真实行情 | 可用于研究性决策 |
| `snapshot` | 离线合成快照 | 标 `DEMO`，禁止交易动作 |

### 6.2 未收盘 K 线剔除

```python
def _drop_unclosed_today(df):
    now = utcnow() + 8h
    if now.hour > 15 or (now.hour == 15 and now.minute >= 5):
        return df
    return df[df['date'] != today]   # 15:05 前丢弃当日
```

原因：盘中三源都会返回「今日」这根没走完的 K 线，量比会变成 0.13 这种失真值。
**日频信号只用已收盘 K 线**；实时价只用于展示与市值。

### 6.3 每个源的具体接口

| 函数 | 接口 | 字段处理 |
|---|---|---|
| `_daily_akshare` | `ak.fund_etf_hist_em(period='daily', adjust='qfq')` | 中文列名映射；滚动 1900 天窗口（约 5 年） |
| `fetch_daily_tencent` | `web.ifzq.gtimg.cn/.../fqkline/get?param=sh510300,day,,,N,qfq` | 成交量「手」×100 → 份；无成交额 → 0 |
| `fetch_daily_sina` | `money.finance.sina.com.cn/.../getKLineData` | volume 已是份；无成交额 → 0 |
| `fetch_spot` | `ak.fund_etf_spot_em` → 腾讯 `qt.gtimg.cn` → 新浪 `hq.sinajs.cn` | 东财有 IOPV（折溢价可用）；腾讯/新浪无 IOPV → `premium_available=False` |
| `fetch_index_daily` | 腾讯 → 新浪 | 至少 30 根，否则降级 |
| `fetch_indices` | 新浪实时点位 + 新浪日线算均线状态 | 6 个指数：上证/深成/创业板/科创50/沪深300/中证500 |
| `fetch_sector_flow` | 东财 `ulist`（31 个申万一级 BK）→ 腾讯板块排行 | 成交额/占比/涨跌/流通市值 |

限流策略：

```python
def _retry(fn, times=2):
    for i in range(times):
        try: return fn()
        except Exception as e:
            if _is_push2_limited(e): return None   # 断连/限流 → 不重试
            # 其它错误才短暂等待重试
```

原因：东财 push2 对高频请求会封 IP，重试会延长封禁（首次约 5 分钟，反复触发 40 分钟以上）。

### 6.4 缓存与重置

| 缓存 | 键 | 生命周期 |
|---|---|---|
| `_CACHE['daily']` | code | 单次运行 |
| `_CACHE['spot']` | — | 单次运行 |
| `_CACHE['index_daily']` | code | 单次运行 |
| `data/cache/daily_<code>.csv` | code | 跨运行（离线兜底） |

`loader.reset()` 在每次 `pipeline.run()` 开头清空内存状态与来源标记，防止上一次的 `live` 标记污染这一次。

### 6.5 来源报告

```python
def source_report():
    daily_live = all(v == 'live' for v in STATE['daily'].values())
    index_live = all(...)
    spot_live  = STATE['spot'] == 'live'
    synthetic = not (daily_live and spot_live and index_live)
    degraded  = not (daily_live and spot_live and index_live)
    premium_ok = spot_live and STATE['spot_vendor'] == 'akshare'
```

`market.json` 的资讯/情绪**不算决策输入**，只标 `market_snapshot=True`，不影响 `synthetic`。
原因：市场状态由真实指数日线算出，资讯只是展示。

---

## 7. 数据质量与状态机

### 7.1 逐腿检查（`quality.check_bars`）

| 检查 | 代码 | 结果 |
|---|---|---|
| 空数据 | `len(df)==0` | `ABSTAIN` + 阻断项 |
| 日期不可解析 | `pd.to_datetime(errors='coerce').isna().any()` | 阻断 |
| 日期重复 | `date.duplicated().any()` | 阻断 |
| 日期非升序 | `not is_monotonic_increasing` | warning，排序后使用 |
| OHLC 矛盾 | `high < max(open,close)` 或 `low > min(open,close)` | 阻断 |
| 非正价格 | 任一 OHLC ≤ 0 | 阻断 |
| 负成交量 | `volume < 0` | 阻断 |
| 根数不足 | `< MIN_BARS(30)` | 阻断 |
| 陈旧 | `as_of − last_date > 5 个自然日` | 阻断 |
| 合成数据 | `is_synthetic=True` | 只 warning，状态 `DEMO` |

状态判定：

```
有阻断 → ABSTAIN
否则合成 → DEMO
否则有 warning → DEGRADED
否则 → OK
```

### 7.2 状态合并

```python
order = {'ERROR':5, 'ABSTAIN':4, 'DEMO':3, 'DEGRADED':2, 'OK':1}
merge_status(*statuses) → 取最大
```

额外规则：

- `src.synthetic` → 整体 `DEMO`；
- 整体 `OK` 但基准指数不是 live → `DEGRADED`（状态来自快照，不能声称全真）。

### 7.3 页面如何消费状态

| 状态 | 页面行为 |
|---|---|
| OK | 正常展示 |
| DEGRADED | 顶部徽标 + 缺失处「缺失/未接入」 |
| ABSTAIN | 只给事实；动作列 `ABSTAIN`；不发订单 |
| DEMO | 徽标 title「仅演示，不输出交易动作」；`decide` 返回 ABSTAIN |
| ERROR | 不发布新产物（保留上一份） |

`packet.validate_packet()` 会**强制校验**：`ABSTAIN/DEMO/ERROR` 下不允许出现任何可执行动作。

---

## 8. 指标层（`features.py`）

### 8.1 输入输出

- 输入：单只 ETF 的日线 DataFrame（`date/open/high/low/close/volume/amount`）。
- 输出：逐日特征 DataFrame（多列），`last_dict()` 取最后一行转纯 dict。

### 8.2 列级公式（完整）

| 列 | 公式 | 备注 |
|---|---|---|
| `ma5/10/20/60/120` | `close.rolling(n).mean()` | 周期来自 `strategy.ma.periods` |
| `vol_ratio` | `volume / volume.rolling(5).mean().shift(1)` | **不含当日**，否则放量会自我稀释 |
| `expand` / `shrink` | `vol_ratio ≥ 1.30` / `≤ 0.80` | 阈值来自配置 |
| `change_pct` | `close.pct_change()*100` | 缺首日填 0 |
| `high20/low20/high60/low60` | `rolling(n).max/min` | |
| `prev_low` | `low.rolling(6).min().shift(1)` | 前 5 日最低（不含当日） |
| `pos20` | `(close − low20) / (high20 − low20)` | 0=区间底，1=区间顶 |
| `days_above_ma5` | 连续 `close > ma5` 计数 | 遇 False 归零 |
| `below_ma10_2d` | 连续 `close < ma10` 计数 | 名字沿用旧字段，实际是「连续天数」 |
| `stand_back` | `close > ma5` | |
| `add_ready` | `days_above_ma5 ≥ 3` | 加仓前置 |
| `ma_bull/ma_bear` | `ma5>ma10>ma20` / 反之 | |
| `tangle_pct` | `(max(ma5,ma10,ma20) − min(...)) / ma20 × 100` | |
| `ma_tangle` | `tangle_pct < 1.2%` | |
| `tb_hold_key` | `close > ma10 且 close > low20×0.995` | 突破四条之一 |
| `tb_shrink` | `shrink` | 之二 |
| `tb_slow_fast` | `close > close[-8]×1.01 且 昨日跌幅 > −2%` | 之三（慢跌快涨） |
| `tb_support` | 下影线 >0.4% 或 阳线 或 `low ≥ 昨低×0.998` | 之四（有承接） |
| `true_breakout_count` | 四条之和（0–4） | |
| `true_breakout` | 计数 == 4 | |
| `false_breakout` | `expand 且 close<昨收 且 close<ma20` | 可观测事件 |
| `upper_shadow_pct` | `(high[-3] − max(open[-3],close[-3])) / close[-3] × 100` | **固定倒数第三根** |
| `ret5/ret20` | `close/close.shift(n) − 1`（%） | |
| `is_20d_low` | `close ≤ low.rolling(20).min()` | |
| `vol20/vol60` | `std(pct_change, n) × √252 × 100` | 年化波动 % |

### 8.3 为什么上影线取倒数第三根

早前生产用「当日」、回测用「倒数第三根」，同一根 K 线得到不同结论。
统一为 `-3` 后，规则卡 R-C2（上影线 > 2%）在生产与回测命中同一事件。

### 8.4 状态文案（`indicators/__init__.py`）

| 函数 | 输出 | 规则 |
|---|---|---|
| `five_state` | 未站回MA5 / 站回MA5·N日 / 站上MA5第N日 | N≥3 才算「站上」 |
| `vol_desc` | 放量上涨 / 放量下跌 / 缩量回调 / 缩量上行 / 量能平淡 | 量比 + 当日涨跌 |
| `cycle_phase` | 下行趋势 / 均线缠绕 / 上行趋势 / 弱势 / 震荡区间 | 连续低于 MA10 ≥2 且 <MA20 → 下行 |
| `breakout_label` | 突破四条全中 / 突破四条 n/4 / 放量下跌破MA20 | 假突破优先 |
| `ma_state` | 多头排列 / 空头排列 / 聚集缠绕 / 交织 | |

文案里**不出现**「主力出货 / 诱多 / 真突破 = 出货」这类不可观测断言。

---

## 9. 规则卡

### 9.1 10 条规则（按优先级）

| 优先级 | ID | 等级 | 动作 | 名称 | 条件 |
|---|---|---|---|---|---|
| 100 | R-D1 | D | CLEAR | 收盘跌破 MA10 | 连续低于 MA10 ≥ 2 日 |
| 99 | R-D2 | D | CLEAR | 放量下跌破 MA20 | `false_breakout=True` |
| 98 | R-D3 | D | CLEAR | 放量破位 | 放量 + 跌幅 <−2% + 收盘 <MA20 |
| 97 | R-D4 | D | CLEAR | 20 日新低 | 20 日新低 + 连续低于 MA10 ≥1 |
| 80 | R-C1 | C | TRIM | 未站上 MA5 且放量 | `not_stand_back & expand` |
| 79 | R-C2 | C | TRIM | 上影线超阈值 | 倒数第三根上影线 >2% |
| 78 | R-C3 | C | TRIM | 折溢价偏高 | 未站上 MA5 且折溢价 >1%（IOPV 缺失不命中） |
| 60 | R-A1 | A | ADD | 站上 MA5 且突破四条 | 站上 MA5 ≥3 日 + 四条全中 |
| 50 | R-A2 | A | HOLD | 站上 MA5 确认 | 站上 MA5 ≥2 日 |
| 20 | R-B1 | B | HOLD | 缺确认等待 | `always`（兜底） |

### 9.2 4 条组合覆盖（只作用于 ADD）

| ID | 条件 | 效果 |
|---|---|---|
| O-1 | 当前总仓位 > 阶段区间上限 | ADD → HOLD |
| O-2 | 单腿浮亏 < −8% | ADD → HOLD |
| O-3 | 单腿浮盈 > +30% | ADD → HOLD |
| O-4 | 关键数据缺失/陈旧/冲突 | 任意 → ABSTAIN |

### 9.3 谓词真值表

| 谓词 | 为真条件 | 数据缺失时 |
|---|---|---|
| `below_ma10_days_gte` | 连续低于 MA10 天数 ≥ N | False |
| `false_breakout` | 放量 + 收跌 + 收盘 <MA20 | False |
| `expand_down_break_ma20` | 放量 + 跌幅 <−2% + 收盘 <MA20 | False |
| `not_stand_back_expand` | 未站上 MA5 + 放量 | False |
| `upper_shadow_gt` | 倒数第三根上影线 % > N | False |
| `not_stand_back_premium_gt` | 未站上 MA5 + 折溢价 >N | False（缺失 ≠ 满足） |
| `stand_back_days_gte` | 站上 MA5 + 连续天数 ≥ N | False |
| `true_breakout` | 四条全中 | False |
| `is_20d_low` | 收盘为 20 日新低 | False |
| `always` | 恒真 | 恒真 |

**统一原则：缺失数据一律「不命中」**，由质量层决定 ABSTAIN；
绝不用「缺失 = 满足」把风险规则放过去。

### 9.4 求值与覆盖

```python
def decide(feat, data_status='OK', overrides=None):
    if data_status == 'ABSTAIN':  return ABSTAIN + ['O-4']
    if data_status == 'DEMO':     return DEMO + ABSTAIN（只演示命中哪条）

    r = match_rule(feat)                    # 按 priority 降序，第一条全条件命中
    if r is None: return DEGRADED + ABSTAIN # 没有兜底 = 配置错误

    action, level = r['action'], r['level']
    if action == 'ADD':
        if pos > regime_hi:  action = 'HOLD'; blocked_by.append('O-1')
        elif pnl < -8:       action = 'HOLD'; blocked_by.append('O-2')
        elif pnl > 30:       action = 'HOLD'; blocked_by.append('O-3')
    return OK + {level, action, rule_ids, hits, blocked_by}
```

### 9.5 规则卡与页面的关系（重要）

| 用途 | 是否影响页面动作 |
|---|---|
| 数据闸门（ABSTAIN） | 是：数据不足直接不给动作 |
| 最早减仓时点（R-D/C） | 间接：写进个股卡解释与 `packet.legs.action` |
| 目标仓位大小 | **否**：目标只由 `plan_v3` 决定 |
| 页面「动作」列 | **否**：只由「目标 − 现仓」派生 |

这条边界是「唯一出口」的核心：规则说「可以减」，但减到多少由目标决定。

---

## 10. 市场状态与相对强弱

### 10.1 状态分类

```python
if last > ma60 and ma5 > ma20:      base = '上行趋势'
elif last < ma60 and ma5 < ma20:    base = '下行趋势'
else:                                base = '震荡区间'
regime = base + (' · 波动抬升' if vol20 > vol60 * 1.25 else '')
```

配套输出：

| 字段 | 计算 |
|---|---|
| `fit_lo/fit_hi` | `risk.regime_fit[regime]` |
| `close` | 最后一根收盘 |
| `ma5…ma120` | 各周期均线 |
| `ma_spread_pct` | `(max(ma5,ma20,ma60)/min(...) − 1)×100` |
| `days_above_ma5` | 连续站上 MA5 天数 |
| `gaps` | 近 20 日未回补缺口（最多 3 个） |
| `position` | 近 120 日高/低、距高/低、上下空间、赔率、区间宽度 |

### 10.2 缺口识别

```
向上缺口：当日最低 > 前日最高，且此后最低从未回到前日最高下方
向下缺口：当日最高 < 前日最低，且此后最高从未回到前日最低上方
```

只保留最近 3 个。缺口的意义写在页面：上方未补 = 多头没信心；缺口回补才有像样行情。

### 10.3 赔率

```
向上空间 = (high120 − last) / last × 100%
向下空间 = (last − low120) / last × 100%
赔率     = 向上空间 ÷ 向下空间
```

页面必须跟一句解释：**赔率只描述位置，不预测何时到；贴近前低时会被显著放大。**

### 10.4 相对强弱

```
excess5  = 标的 5 日收益 − 基准 5 日收益（同日收盘）
excess20 = 同理
```

- 基准日期与标的日期不一致 → `is_known=False`，标签「未知」，不得加分。
- `ahead = excess5 > 0.5 且站上 MA5`。
- 标签：20 日新低且低于 MA10 → 「20日新低 · 弱于基准」；ahead 且放量 → 「强于基准（超额 + 放量）」；ahead 无放量 → 「强于基准（无放量确认）」；`excess5 ≥ −0.5` → 「同步」；否则「弱于基准」。

---

## 11. 组合层（目标权重）

### 11.1 `plan_v3._indicators()` 的逐步推导

```python
c = close; ma5, ma10, ma20, ma30, ma60 = 各周期均线
vol20 = std(pct_change, 20) × √252 × 100

# 评分（0–100）
score = 50
score += 15 if last > ma20 else -15
score += 10 if ma5 > ma10 > ma20 else (-10 if 反向排列 else 0)
score += 5  if last > ma60 else 0
score -= 10 if last <= low20 else 0
score = clamp(score, 0, 100)

# 周线方向：周收盘 > 20 周线（只取已结束的周）
wk = resample('W-FRI').last()
wk_up = wk[-1] > wk.rolling(20).mean()[-1]

# 确认条数（0–3）
confirm = (last > ma10) + (DIF > DEA) + (连续 2 日量增价涨)
```

### 11.2 目标权重分配

```
total = (fit_lo + fit_hi) / 2                 # 状态中枢
coef  = (0.6 + 0.4 × score/100) × min(1, 15/vol20)
        # 评分越高、波动越低，系数越大
按 coef 降序取前 6 只（TOP_N）
denom = Σ coef(前 6)
target = min(25%, CAP[grade], total × coef / denom)
```

为什么用 `min(1, 15/vol20)`：波动越大，同样的评分应给更少权重。
为什么取前 6：避免极度分散导致单只权重过小、交易成本吃掉收益。

### 11.3 评级与 tier

```
grade: ≥85 S / ≥75 A / ≥60 B / ≥50 C / else D
CAP  : S25 / A20 / B10 / C5 / D3
tier : below60 或 below30 → 可一次性卖差额
       below20            → 先卖一半
       close < ma10       → 只回目标，不追卖
       其它               → 结构未坏，也只减一半
```

### 11.4 板块压缩（前端）

```js
// 同板块目标合计 > 板块上限 → 按比例缩放
sum = Σ target(该板块)
if (sum > cap) target *= cap / sum
```

板块上限来自 `sectorScore().cap`（S25/A20/B10/C5/D0）。
D 级上限 0 只限制**新增**，不强制清仓（已持有的按个股规则处理）。

### 11.5 池外持仓补算（前端，三级）

| 级别 | 条件 | 算法 | 动作 |
|---|---|---|---|
| 1 | 后端 `plan.items` 有这只 | 直接用 | 正常 |
| 2 | 无、但能取到 ≥30 根日线 | `clientSignals()` 与 `plan_v3` 同公式 | 正常，标「池外补算」 |
| 3 | 连 30 根日线都没有 | 类别结构目标折算 | `WAIT`，不生成订单 |

类别结构目标：

```
该类别额度 = 总上限 × structure_target_of_invested[类别] / 100
同类每只 = min(单只上限, 该类别额度 ÷ 同类只数)
```

结构比例：宽基 50 / 行业 25 / 债券 15 / 黄金 5 / 海外 5。
超出总上限时统一按比例缩回。

为什么需要这一层：后端只加载观察池 4 只，而用户持仓常有行业 ETF、债券 ETF、海外 ETF；
不补算就会出现「一屏都是不设目标」，用户无法使用。

---

## 12. 执行层

### 12.1 参考价位（`pricing.prices`，后端）

| 动作 | entry | stop | tp |
|---|---|---|---|
| CLEAR | 现价（限价保护） | None | None（目标份额 0，不设止盈） |
| 卖出（TRIM） | `max(现价×1.008, MA5)`，且不高于 20 日高 | 下方支撑中最低的一档，且不低于现价×0.96 | `max(20日高, 现价×1.05)` |
| 买入（ADD/HOLD/WATCH） | 第一档支撑 ×0.998，且不低于现价×0.96 | 更下一档支撑，且不低于 entry×0.94 | `max(20日高, 现价×1.06)` |

约束：买入必须满足 `stop < entry < tp`，否则整体返回 None 并注明「价位关系不成立」。

取整：`_r()` 用 half-up（四舍五入），与 JS `Math.round` 一致；
Python 内置 `round` 是银行家舍入，会造成 0.001 的差异。

### 12.2 页面订单（`orderTicket`，前端）

```
输入：持仓行 r、目标权重 targetW、总资产 total、可选限制 opt
1. 目标/价格/总资产缺失 → 直接返回原因
2. side = 目标 > 现仓 ? buy : (目标 < 现仓 ? sell : null)
3. limit = 买 ceil(现价×1.0001 / 0.001)×0.001
           卖 floor(现价×0.9999 / 0.001)×0.001
4. shares = floor(total × targetW/100 / limit / 100) × 100
   买入时 shares 不低于现有份额
5. delta = shares − 现有
   |delta| < 100 → 「不足一手」
6. 买入：可买手数 = floor(现金/limit/100)×100
   不够 → 下调并标「受现金限制」/「现金不足」
7. 成交额 < 0.1 亿 → 「流动性不足」；停牌 → 「停牌」
8. fee = max(5, 成交额×0.5bp) + 成交额×1bp
9. first = 卖出 |delta|×50% 向下取整到 100 份
```

### 12.3 为什么挂单价要「朝更优方向取整」

- 买：向上进位 → 限价不低于目标价，成交概率更高；
- 卖：向下截断 → 限价不高于目标价，更容易成交；
- 两边都取到 0.001（ETF 最小变动价位），避免因取整把保护价吃掉。

### 12.4 六条边界为什么必须写死

| 边界 | 若不处理会怎样 |
|---|---|
| 目标缺失 | 会按 0 计算 → 误判清仓 |
| 价格缺失 | 会 produce NaN → 页面显示 0 份 |
| 不足一手 | 会显示 0 或负数 |
| 现金不足 | 会生成买不起的订单 |
| 流动性不足 | 挂单无法成交却看起来可执行 |
| 停牌 | 同上 |

每条都有独立文案，不合并成「—」。

---

## 13. 数据包与不变量

### 13.1 结构与哈希

```
input_hash  = sha256(逐腿 {code, data_date, data_status})[:16]
config_hash = sha256(全部 config)[:16]
run_id      = 运行时刻 + '-' + input_hash
```

同源校验：`run_id` 必须同时出现在 `analysis_packet.json`、`last_run.json`、HTML 内嵌数据中。

### 13.2 `validate_packet()` 的校验项（逐条）

| 类别 | 校验 | 违反后果 |
|---|---|---|
| 结构 | 10 个必填字段齐全 | error |
| 状态 | status 在 5 个合法值内 | error |
| 状态一致性 | `ABSTAIN/DEMO/ERROR` 下不得有 `INITIATE/ADD/TRIM/EXIT/CLEAR` | error |
| 组合 | 快照不完整只 warning（缺价清单） | warning |
| 决策 | 目标份额非负 | error |
| 决策 | CLEAR/EXIT 的目标份额必须为 0 | error |
| 决策 | 非交易动作不得给目标份额 | error |
| 决策 | `target − current == delta` | error |
| 决策 | 非 HOLD/WATCH/ABSTAIN 必须有 `reason_ids` | warning |
| 订单 | 同一代码不得重复下单 | error |
| 订单 | 订单必须有对应决策 | error |
| 订单 | 份额变化不得为 0 | error |
| 订单 | 方向与动作一致（加仓为正、减仓为负） | error |
| 订单 | 费用非负、价格有效 | error |
| 发布 | 标 `published=True` 且有差额 → 必须有订单 | error |
| 发布 | 标 `published=False` → 不得展示目标份额 | error |
| 账务 | `现金 + 市值 = 总资产`（误差 ≤1 元） | error |
| 账务 | 现金不得为负 | error |
| 仓位 | `position_pct + cash_pct ≈ 100`（误差 ≤0.5） | error |
| 约束 | 执行后单只 ≤25%、类别 ≤60%、腿数 ≤8、现金 ≥5% | error |
| 逐腿 | `data_status` 合法 | error |
| 逐腿 | 状态 OK 且非 HOLD/WATCH 必须有 `rule_ids` | error |
| 逐腿 | ABSTAIN/DEMO 不得有交易动作 | error |
| 契约 | 决策 `run_id` / `input_hash` 与数据包一致 | error |
| 契约 | 决策校验失败时数据包不得标 OK | error |

共 20+ 条，全部在发布前跑一遍；失败即退出码 4，**不推送**。

### 13.3 为什么订单数组是空的

`pipeline` 里的 `orders=[]`，`decisions[].current_shares/target_shares=None`。
原因：服务端拿不到个人持仓，无法算份数。
页面的订单由浏览器 `orderTicket()` 用解密后的持仓现算。
这是设计，不是缺口；文档与页面都要说明，避免误解为「订单丢失」。

---

# 第三部分 页面实现

## 14. 单文件生成与 DASHBOARD

### 14.1 生成

```python
payload = json.dumps(data, ensure_ascii=False)
payload = payload.replace('<', '\\u003c').replace('>', '\\u003e')   # 防止 </script> 截断

html = (SHELL.replace('@@CSS@@', css)
             .replace('@@DATA@@', payload)
             .replace('@@JS@@', rules_js + '\n' + decision_js + '\n' + app_js))
```

三处占位：`@@CSS@@`、`@@DATA@@`、`@@JS@@`。
输出 `web/index.html`，约 320 KB，无外部样式与脚本依赖。

### 14.2 DASHBOARD 结构与页面消费

| 键 | 内容 | 谁消费 |
|---|---|---|
| `meta` | 日期、状态、来源、run_id | 顶部徽标、日期提示 |
| `packet` | 数据包摘要 | 状态与校验展示 |
| `market` | 指数、广度、情绪、轮动、分布、折溢价、估值、外围、资金、宏观、新闻、日历、政策、热度、成交、国家队、状态 | p1 全部；p5 环境 |
| `legs` | 逐只特征与证据卡 | 个股卡、候选 |
| `orders` | 公开池订单（空） | 仅记录 |
| `plan` | 总目标、区间、逐只目标/评级/上限/确认 | 明细表、点评、洞察 |
| `targets` | 类别结构目标 | 池外补算 |
| `sector_weights` | 指数→行业权重、ETF→指数 | 板块映射 |
| `brief` | 外部点评（可为 null） | 点评优先来源 |
| `contract` | 约束参数 | 前端校验 |
| `methodology` | 动作文案 | 展示 |

## 15. 前端计算细节

### 15.1 解锁与解密

```js
// 口令 → PBKDF2-SHA256(210,000, 16B salt) → AES-GCM-256 密钥
crypto.subtle.importKey('raw', pass, 'PBKDF2', ...)
  .then(k => crypto.subtle.deriveKey({salt, iterations, hash:'SHA-256'}, ...))
// 解密 {v,kdf,iter,salt,iv,ct}
crypto.subtle.decrypt({name:'AES-GCM', iv}, key, ct)
  .then(buf => JSON.parse(new TextDecoder().decode(buf)))
```

边界：

- 非 https/localhost → `crypto.subtle` 不可用，提示「当前环境不支持浏览器解密」；
- 没有密文 → 显示「创建空持仓」入口；
- 口令错误 → 「口令不对，或密文文件已损坏」，不泄露细节。

### 15.2 盈亏计算（`calcPort`）

```
每只：
  last = 实时价（缺则 null）
  mv   = last × shares
  pnl  = (last − cost) × shares
  day  = (last − prev) × shares
     若缺 prev 但有涨跌幅 chg：day = shares × (last − last/(1+chg/100))

组合：
  totalPos = Σ mv
  totalAsset = totalPos + cash        # 只有全部有价才成立
  pnlPct = Σpnl / Σ(cost×shares)
  dayPnlPct = Σday / Σ(prev×shares)
```

为什么不用总资产做分母：现金会稀释百分比，同一只股票在不同现金比例下看起来盈亏不同。

### 15.3 K 线清洗（`sanitizeBars`）

| 规则 | 原因 |
|---|---|
| 非正收盘丢弃 | 停牌/脏数据 |
| OHLC 矛盾行丢弃 | 源站错误 |
| 未收盘当日剔除（15:00 前） | 与后端同口径 |
| 日期排序去重 | 多源拼接可能重复 |
| 最后日期距今 >30 天 → 整段作废 | 长假后放宽（原为 15 天） |
| <20 根 → null | 无法算均线 |

### 15.4 日线/周线获取

```
fetchBars(code)
  → fetchBarsTencent（900 根，JSONP，7s 超时）
  → 失败或 <20 根 → fetchBarsEm（东财 K 线，900 根，JSONP，8s）
  → 都失败 → null

RS_WEEK[code]
  → rsFetchWeekly（腾讯周线，260 根，9s 超时）
  → 失败 → rsWeeklyFromDaily（按周四归组聚合）
```

`rsWeeklyFromDaily` 的必要性：周线接口常被跨域拦截；没有周线就算不出 20 周线，
月线也无法聚合。用日线聚合后，20 月线至少可算（900 根 ≈ 41 个月）。

### 15.5 池外补算（`clientSignals`）

与 `plan_v3` 同公式，差异仅在数据来源：

```
ma5/10/20/30/60、low20、vol20（20 日年化）
score = 50 ±15 ±10 +5 −10
confirm = (last>ma10) + (DIF>DEA) + (连续 2 日量增价涨)
wk_up = 周收盘 > 20 周线
grade/cap/tier 与后端同一张表
```

### 15.6 双评分卡（`legScore`）

| 卡 | 项 | 分值 | 判定 |
|---|---|---|---|
| 底部 | 月线底背离 | 25 | 月线创新低且 DIF 抬高 → 25；DIF 仍负 → 15；否则 8/0 |
| 底部 | 倍量站上 20 月线 | 20 | 站上且量 >5 月均量×1.5 → 20；站上 → 10；否则 0 |
| 底部 | 周线多头排列 | 15 | 5>10>20>30 → 15；5>10 且 >30 周线 → 10；粘合 → 5；否则 0 |
| 顶部 | 月线顶背离 | 30 | 创新高但 MACD 柱缩短 → 30；否则 15/10/0 |
| 顶部 | 跌破 10 月线 | 20 | 是 → 20 |
| 顶部 | 周线死叉 | 15 | 5<10 且 <30 周 → 15；仅 5<10 → 10 |
| 顶部 | 板块过热 | 10 | 板块成交占比 ≥15% → 10；≥10% → 5 |

归一：按已有项权重折算到 100；缺项数在卡片上明示（底部 7 项、顶部 6 项）。
顶部 ≥80 → 单只上限 0；≥60 → 上限 5%；≥40 → 上限减半。

### 15.7 概率（`rsForecast`）

```
特征：20 日动量 + 20 日波动
样本：历史上所有 t（t ≥ 20 且 t+h < n）
距离：二维标准化欧氏距离
取近邻：k = max(10, round(√n × 4))
权重：高斯核 exp(−0.5 × (d/band)²)，band = 近邻距离中位数（≥0.35）
输出：上涨占比（加权）、加权中位涨幅、有效样本数（1/Σw²）
```

样本 <20 → 该周期返回 null；页面整列显示「样本不足」。
概率不参与评级与动作。

### 15.8 缠论（`rsChanOf` / `rsChanText`）

```
分型：左右各 2 根
笔  ：顶底交替，间隔 ≥4 根，幅度 ≥1.5%
中枢：最近 4 笔的 3 段重叠，ZG = min(各段高)，ZD = max(各段低)
底背驰：最后是下降笔，价格创新低而 DIF 抬高
顶背驰：最后是上升笔，价格创新高而 DIF 走低
三买：现价 > ZG
```

`rsChanText()` 把结构翻译成六行：

| 行 | 内容 |
|---|---|
| 中枢 | ZG/ZD 或「尚未形成中枢」 |
| 现价位置 | 中枢上方（距 ZG +x%）/ 中枢内 / 中枢下方（距 ZD −x%） |
| 最近一笔 | 向上/向下笔 起价 → 止价（±x%） |
| 结构信号 | 底背驰 / 顶背驰 / 三买 / 无 |
| 与目标的关系 | 按「动作 × 信号 × 位置」三维查表（见下） |
| 持仓上下文 | 评级·上限 · 现仓→目标 · 板块及占比 · 大盘状态 |

「与目标的关系」真值表：

| 动作 | 信号/位置 | 文案 |
|---|---|---|
| 减仓 | 底背驰或三买 | 结构有企稳迹象，但仍按 50/30/20 减，不必一根大阴线砍完 |
| 减仓 | 中枢下方 | 弱势区，减仓不用等反弹，按计划执行 |
| 减仓 | 其它 | 无反向买点，按目标执行 |
| 加仓 | 顶背驰 | 不追高，等回踩中枢上沿不破 |
| 加仓 | 中枢下方 | 只做试错仓，等站上 ZG |
| 加仓 | 其它 | 不反对，按确认条件分批 |
| 持有/等待 | 底背驰 | 只是观察理由，差额不足仍不动 |
| 持有/等待 | 顶背驰 | 提示风险，但不加仓、不提前卖 |

冲突裁决：

- 个股在中枢上方 + 大盘下行 → 以大盘定总上限，个股强势只减不追；
- 顶背驰 + 目标要加 → 以目标为准，但等回踩；
- 底背驰 + 目标要减 → 以目标为准，买点只用来细分减仓节奏。

**缠论不改目标、不改订单**；要接入必须先在 `docs/缠论融合回测方案.md` 的 A/B 中过门槛。

### 15.9 市场洞察（`marketOutlook`）

定性打分：

```
状态：上行 +2 / 下行 −2 / 震荡 0
MA5 vs MA20：上 +1 / 下 −1
上涨家数占比：>55% +1 / <45% −1 / 其它 0
情绪分：≥65 +1 / ≤35 −1
总分 ≥2 偏多；≤−2 偏空；否则震荡
```

情绪温度：

```
温度 = 情绪分×40% + 上涨占比×35% + 成交额分×15% + 趋势分×10%
成交额分 = clamp(50 + 环比×1.5, 0, 100)
趋势分   = 50 ±15（上行/下行）
```

情景三行（价位全部来自真实数据）：

| 情景 | 触发 | 当前距离 |
|---|---|---|
| 偏弱延续 | 收盘跌破近 120 日低点 | 现价距前低 x% |
| 震荡修复 | 前低 ~ MA20 | 现价距 MA20 ±x% |
| 转强确认 | 站上 MA20 且 MA5 上穿 MA20 | 需再涨 x% |

### 15.10 候选（`buildIdeas`）

过滤顺序（任一不满足即剔除）：

1. 已在持仓 → 剔除；
2. 名称/类别命中不碰名单（军工、传媒、游戏、次新）→ 剔除；
3. 所属板块评分 C/D 或缺失 → 剔除；
4. 同类别只留一只；
5. `excess5 < 0` → 剔除（近 5 日弱于大盘）；
6. 剩余额度 <3pct → 只写「观察」。

### 15.11 复盘对照

- `rsStoreSnapshot()`：把当日 `RS_PLAN` 的 `{code,name,target,grade}` 存进 `localStorage`；
  数据日变化时把 `cur` 移到 `prev`。
- `rsRenderReview()`：逐只对比上次与今天的目标、评级，标出变化只数；
  页面明写「对照的是计划，不是成交回报」。

---

## 16. 页面逐块（内容 + 代码 + 数据）

### 16.1 p1

| 区块 | 函数 | 数据 | 关键实现 |
|---|---|---|---|
| 快照日提示 | `page1()` | `meta.snapshot_date` | 与 `data_date` 不同则提示 |
| 四卡 | `page1()` | `breadth/sentiment/regime` | 成交额、情绪分、区间、依据数 |
| 指数表 | `page1()` | `market.indices` | 6 行：最新/涨跌/均线状态 |
| 情绪表 | `page1()` | `sentiment.items` | 12 条键值 |
| 阶段→仓位 | `linkStrip()` + `planSection()` | `plan` + `calcPort()` | 差额 <3pct 不动 |
| 热力图 | `heatMap()` + `squarify()` | `market.heat` | 面积=市值，颜色=涨跌（±0.5/1.5/3/5%） |
| 国家队 | `nationalTeamSection()` | `national_team.series[-1]` | 只最新一期；跳动 >15% 合并提示 |
| 行业表 | `page1()` | `market.flow` | 按成交额降序 |
| 轮动/分布 | `page1()` | `regime` + `distribution` | 6 档柱 |
| 宏观四块 | `page1()` | `valuation/glob/liquidity/macro` | 固定说明「人工快照」 |
| 政策消息 | `page1()` | `news/calendar/news_sentiment/policy_heat` | 解读来自 `news_note.json` |

### 16.2 p5 概况

| 区块 | 函数 | 关键逻辑 |
|---|---|---|
| 四卡 | `calcPort()` | 见 15.2 |
| 点评 | `rsRenderBrief()` | 优先 `D.brief`；否则 `rsBriefSections()` |
| 明细表 | `rsPlanRows()` → `rsSortPlanRows()` → `rsPlanRowsHTML()` | 目标三级来源；板块压缩；订单六边界 |

### 16.3 p5 分析

| 区块 | 函数 | 关键逻辑 |
|---|---|---|
| 大盘七项 | `rsPageHTML()` + `maRegime()` | 均线排列 / 五均线 / 量能 / 缺口 / 空间 / 波动 |
| 热度情绪 | `rsPageHTML()` | 恐慌只认放量急杀 |
| 资金 | `rsPageHTML()` | 北向固定说明 |
| 隔夜消息 | `rsPageHTML()` | 前 3 条 |
| 组合暴露 | `rsSectorExposure()` | 占持仓市值；未覆盖单列 |
| 集中度 | `rsRenderSector()` | HHI、TMT 合并、现金 |
| 一致性 | `rsRenderSector()` | 先结论后证据 + 未映射说明 |
| 板块健康度 | `sectorScore()` + `rsSectorHealth()` | 四维归一 |
| 个股卡 | `rsRenderDetail()` | 九块 |

### 16.4 p5 洞察

| 区块 | 函数 |
|---|---|
| 定性 | `rsRenderMarket()` |
| 位置赔率 | `rsRenderMarket()` |
| 情绪主线 | `rsRenderMarket()` |
| 情景 | `rsRenderMarket()` |
| 复盘 | `rsRenderReview()` |
| 候选 | `buildIdeas()` + `rsRenderIdeas()` |

### 16.5 p7

`page7()`：工具栏、快速添加、编辑表、汇总、云端配置。
所有编辑先写 `EDIT` 草稿，`draftCalc()` 实时算汇总，`saveCloud()` 才加密上传。

---

## 17. 为什么个股卡是九块、为什么这个顺序

| 顺序 | 块 | 回答的问题 | 不放在前面的原因 |
|---|---|---|---|
| 1 | 结论 | 这只现在做什么、多少量、什么价 | 一进来就要答案 |
| 2 | 进场检查 | 如果要买，条件够不够 | 先有结论，再验证 |
| 3 | 三周期 | 月/周/日各是什么状态 | 方向依据，放在动作之后避免「先看技术再找理由」 |
| 4 | 双评分卡 | 强弱打分 | 与三周期互补，都是解释 |
| 5 | 结构图 | 笔/中枢/买卖点 | 图形最占空间，放后面 |
| 6 | 缠论结构 | 结构翻译成人话 | 只解释，不影响动作 |
| 7 | 概率 | 历史相似条件 | 参考项，不能放前面诱导 |
| 8 | 怎么做 | 目标、差额、确认、分批 | 执行细节 |
| 9 | 改判 | 什么条件推翻 | 最后给退出机制 |

一句话：**结论 → 证据 → 图形 → 参考 → 执行 → 改判**。
概率虽在块 7，但文案固定「只作参考，不改评级、不改动作」。

---

# 第四部分 分析与提示词

## 18. 两类 LLM 任务与职责边界

| 工作流 | 用途 | 允许解释动作 | 禁止 |
|---|---|---|---|
| A 公开市场摘要 | 只总结公开行情 | 否 | 出现 `action`、价格、份数、胜率 |
| B 本机持仓解读 | 结合解密后的持仓 | 是，但只能原样解释 | 修改任何字段值 |

判定规则：同一次输出若含持仓，按 B 处理，并在开头注明「含本机持仓解读，不用于公开发布」。

## 19. 今日点评提示词

### 19.1 外部生成契约（`skills/portfolio-brief/SKILL.md` 全文）

```markdown
---
name: portfolio-brief
description: 生成持仓分析页「今日点评」的数据文件 data/brief.json。一次运行产出一份，页面只读、不改写。日期不一致、结构不合法或含禁词的，页面会丢弃并回退到本机引擎。
---

# 今日点评

输入：web/analysis_packet.json、data/brief_inputs.json（当次运行的行情、板块、资金、国家队、持仓与目标仓位）。
输出：data/brief.json。

## 输出结构

{
  "data_date": "2026-11-19",
  "conclusion": "一句话基调",
  "blocks": [
    {"k": "今天是什么日子", "v": "……", "refs": ["market.breadth", "market.glob"]}
  ]
}

- data_date 必须等于当次页面数据日；不一致整份作废。
- blocks 至少 6 块，k 不重复，v 不得为空。
- refs 写数据字段路径，便于回查；没有可不写。

## 必须覆盖的七类信息

大盘位置、量能、空间与赔率、行业与主线、资金、宏观与隔夜、自身组合。
缺哪类就在正文写「缺」，不得用别类数据顶替。

## 推理顺序

今天什么日子 → 大盘阶段 → 主要矛盾 → 行业信号 → 资金背景 → 自身偏差 → 今天动什么 → 什么情况下改判。

## 硬性要求

- 每句结论必须带数字，且数字能在页面同一处找到；找不到就不写。
- 动作只能引用目标仓位表（差额→动作→订单），不得另给方向。
- 不设字数、段数、句式限制；像人说话，不像公告。
- 禁止词：注意风险、保持谨慎、密切关注、综合来看、整体合理、酌情处理、有望、可能上涨、保证、必涨、稳赚、胜率。
- 不预测点位，不给目标价；概率类判断必须带样本量。
- 结尾写「价格是执行价，不保证成交。」（页面检测到就不重复追加）
```

### 19.2 页面兜底生成（`rsBriefSections`）的五段逻辑

外部文件缺失时，引擎按下面五段现场拼，**每段都是「判断 + 数字依据」**：

| 段 | 输入 | 生成逻辑 |
|---|---|---|
| 今日基调 | 时段、定性、仓位 vs 上限 | 仓位 > 上限 → 「任务是把这个差额还回去，不是找新机会」；低于上限 ≥5pct → 「有空间但只在确认满足时小步补」；贴合 → 「只做结构调整」 |
| 大盘与量能 | 状态、收盘、MA5/MA20、成交额环比 | 收在 MA20 下方 + 环比 ≤−5% → 「缩量阴跌不是放量恐慌，不急着抄也不急着砍到底」；放量下跌 → 「更像出货，按纪律减」；放量 → 「要看能否延续」；否则 「方向未定，结构优先」 |
| 结构 | 主线、过热板块、最大暴露、最低评级 | 主线 + 过热 → 「即便在主线也不追」；无映射 → 「板块暂缺，按单只计划执行」；最大仓位 = 最低评级 → 「结构错配，优先减它」 |
| 今天动什么 | `RS_PLAN` 中有 `order.delta` 的行 | 有单 → 「买/卖 N 份，挂 x，首批 y，按 50/30/20 分批」；无单 → 「差额不足 3pct 或目标/价格缺失；不动也是动作」 |
| 改判 | 环境阈值 | 转好：收复 MA20 且 MA5 上穿；恶化：连续两日破 MA30 卖出剩余差额 |

### 19.3 外部文件的校验（`webgen._brief`）

```python
banned = _banned()                     # 读不到禁词表 → 全部拒收（回退引擎）
if 日期不符 → None
if blocks 不是列表 / 少于 6 块 / k 重复 / v 为空 → None
if 任一 v 命中禁词 → None
```

返回 None 时页面用引擎，不显示「来源」标签——避免用户误以为降级。

## 20. 消息面解读提示词

写入 `data/news_note.json`：

```json
{"data_date": "2026-11-23", "note": "100 字以内的解读"}
```

规则：

- 材料：`news_sentiment`（分数、标签、正/中/负占比）、`news` 前 3 条、可选 `global` 与 `policy_heat`；
- 100 字以内、一段话、不列点、不用固定套话；
- 必须说清：正面和负面各主要来自哪条消息；这个分数对今天意味着什么（只作背景，不改仓位）；
- 拿不到材料就留空，不猜政策力度、不预测点位；
- 日期必须等于 `snapshot_date`，否则页面不显示（宁可不显示，也不张冠李戴）。

示例（只示意写法）：

> 央行 3200 亿逆回购是主要正面积分，机器人政策给了主题；负面 11% 落在权重股。分数偏暖只说明消息面没拖后腿，开盘仍看量能能不能接住。

## 21. 持仓深度分析提示词（归档工作流 B）

来源：`docs/持仓分析每日运行指导.md`（已归档，不参与每日刷新），核心条款：

### 21.1 两个工作流边界

| 工作流 | 约束文件 | 是否允许解释持仓动作 |
|---|---|---|
| A 公开市场摘要 | `每日运行说明.md` 第四节 | 否 |
| B 本机持仓深度解读 | `持仓分析每日运行指导.md` | 是，但只能原样解释 |

### 21.2 降级硬规则（优先于任何「深度」要求）

| 想做的判断 | 数据不足时只能怎么写 |
|---|---|
| 行业参与面扩散/收缩 | 「仅有当日截面，无法判断扩散或收缩」 |
| 超配来自价格漂移还是加仓 | 「无交易流水，无法归因；仅能说明当前权重偏高」 |
| 中期趋势（MA60 方向） | 「逐仓数据仅含 MA5/10/20，无法判断 MA60 与中期趋势」 |
| 单只的行业/政策驱动 | 「无可验证逐仓关联，仅作组合级背景」 |
| 「新变化」 | 「无历史对照，只陈述当前观察」 |
| 真实账户收益 | 「只有成本口径浮动盈亏，不代表账户累计绩效」 |

### 21.3 分析框架（五节）

1. **证据效力与判断边界**：行情日 vs 基准日、实时 vs 快照、持仓是否完整定价、分类是否完整、基准是否可用；
   区分「市场问题 / 组合问题 / 数据问题」，数据问题不得解读成市场信号。
2. **市场结构**：趋势层级（短期 MA5/MA20、中期收盘 vs MA20/MA60）、波动（20 vs 60 日，抬升与否以标注为准）、
   参与面、情绪与外围、宏观政策；结论落到「风险偏好与仓位纪律」，至少指出一个推翻条件。
3. **组合诊断**：仓位与状态的关系、结构失衡根源、盈亏归因、风险集中、现金弹性、执行可行性；
   区分「规则建议 / 可执行订单 / 执行后模拟」。
4. **逐只诊断**：结构位置、量价关系、相对表现、市场与行业关系、规则动作逻辑、核心矛盾、反证与观察点。
5. **决策与观察**：是否需要动作（风险 → 结构 → 新增）；不需要时属于哪种原因；下次验证什么。

### 21.4 动作四层与反证三层

| 层次 | 字段 | 含义 |
|---|---|---|
| 规则动作 | `legs[].action` | 规则层动作码 |
| 研究候选 | `candidate_state` | `READY` 只表示通过门禁 |
| 可执行订单 | `orders[]` | 实际发布的订单 |
| 执行后可行性 | `validation.ok` | 约束是否通过 |

反证：①已观察到的反向证据（可引用字段）②当前未发现反证（只能写「未提供」）③待验证的失效条件。

### 21.5 禁止事项（原文摘录）

- 不修改或重新推导 `action`、目标权重/份额、订单、风险门禁、规则阈值；
- 不输出未经校准的胜率、上涨概率、目标收益、保证成交价格；
- 不把静态模拟写成已成交，不把「无法判断」写成「继续持有」；
- 不引用已撤回的旧回测收益或胜率结论；
- 不使用「主力吸筹、试盘、出货、诱多」等不可观测因果作为证据；
- 不制造每日必须买卖的节奏；无动作、等待确认都是有效结论；
- 不在数据不足时用行业印象、常识或经验补出结论。

## 22. 上游 skills 的提示词结构与借用点

| Skill | 提示词的作用 | 借到什么 | 是否被代码调用 |
|---|---|---|---|
| `chenguanhe-perspective` | 用 frontmatter `description` 声明触发词（「用沉关河的视角」「稳哥会怎么看」），正文是 5 个心智模型 + 12 条启发式 | 分层顺序、结论先行、可诊断的心态写法 | 否，蒸馏进规则卡与点评结构 |
| `a-share-turning-point` | 声明「月线定方向、周线定节奏、日线定点位」、双评分卡、8 条纪律 | 三层嵌套、评分档→单只上限、20 月线分界 | 否，对应 `legScore()` 与评级表 |
| `topnews` | 全时段舆情：财联社/东财/新浪三路，情感评分 + 板块关联 + 偏多偏空定性 | 情绪字段口径（恐慌、连板、连续普跌） | 否，对应 `market.json` 人工快照 |
| `quant-backtest-strategy` | 回测与风控接口说明 | 成本口径、约束复核、数据边界写法 | 否，对应 `backtest/` |

为什么不让 skill 直接执行：它们依赖外部 MCP/数据源，且输出不可复现；
本系统只把它们的方法论**固化成配置与代码**，运行时不调用 LLM。

## 23. 防幻觉四道闸门

```
① 结构闸门：JSON 结构 / 必填字段 / blocks ≥6
② 日期闸门：data_date == 页面数据日
③ 禁词闸门：12 个词任一命中 → 丢弃
④ 数字闸门：refs 指字段路径；页面同页可核
```

失败处理：**回退引擎文本，不重算交易动作**。
再失败（引擎也拿不到数据）：该块不渲染，其余事实照常显示。

这条流程的意义：LLM 只负责「把已有结论说人话」，
不允许它产生新的价格、仓位、代码或新闻事实。

---

# 第五部分 质量、边界与演进

## 24. 测试与门禁

| 类别 | 文件 | 覆盖 |
|---|---|---|
| 规则 | `test_methodology.py` | 白名单、优先级、求值、配置错误 |
| 数据 | `test_data_quality.py` / `test_datasource_contract.py` | 质量门、列名契约 |
| 状态 | `test_market_regime.py` | 分类、均线、缺口、位置 |
| 组合 | `test_plan_order.py` / `test_calc_port.py` | 目标→差额→订单六边界、四卡分母 |
| 前端 | `test_leg_score.py` / `test_sector_score.py` | 抽取 JS 在 node 执行 |
| 点评 | `test_brief.py` | 日期/结构/禁词 |
| 发布 | `test_publish_guard.py` | run_id 同源、哈希 |
| 回测 | `test_backtest_no_lookahead.py` | 无前视 |
| 冒烟 | `test_smoke.py` | 页面区块存在、无密钥泄露 |

门禁：`node --check` → `pytest -q`（174）→ `run_update --verify`。

## 25. 已实现 / 未实现

### 25.1 已实现

- 三源日线/实时价/指数日线，逐通道降级与来源标记；
- 指标唯一实现、质量门、状态机、字段血缘；
- 规则卡 10 条 + 4 覆盖 + 唯一求值；
- 市场状态 → 仓位区间 → 目标权重 → 差额 → 订单；
- 相对强弱、板块评分、覆盖度、一致性、候选；
- 单文件页面、本地解密、盈亏、池外补算、缠论展示、概率、复盘；
- 市场快照（广度/分布/外盘/折溢价）、宽基份额、指数行业权重。

### 25.2 未实现 / 只展示

| 项 | 影响 |
|---|---|
| 板块技术面（行业代表 ETF 周线） | 四维评分永远缺 1 项 |
| 双评分卡的估值/领先股/景气/资金/龙头 | 标未接入项数 |
| 情绪/连板/恐慌/快讯/政策/估值/宏观/资金面 | 人工快照，日期可能落后 |
| 隔夜 A50 / 铜 | 外围只有 6 项 |
| 缠论进入执行链 | 需先跑 A/B 回测 |
| `brief.json` / `news_note.json` 自动生成 | 缺失则回退引擎 / 不显示 |
| 纪律闸门成块 | 规则散落在个股卡与表下说明 |
| 板块快照自动刷新 | 仍是演示数据 |

## 26. 关键取舍与代价

| 取舍 | 代价 |
|---|---|
| 单一出口（目标仓位表） | 规则卡只能管闸门与最早时点 |
| 持仓只在浏览器算 | 订单无法进入数据包；两份公式需对拍 |
| 数据不足 ABSTAIN | 部分日子没有动作，用户会觉得「空」 |
| 缠论只展示 | 用户可能觉得「没按缠论分析」 |
| 单文件 HTML | 320 KB、内联重复 |
| 规则外置 YAML | 谓词需 Python/JS 双实现 |
| 三日期分离 | 页面必须额外提示，仍易误读 |
| 人工快照 | 有信息价值，但会过期 |

## 27. 风险与下一步

| 风险 | 缓解 |
|---|---|
| 免费源限流 | 立即降级，不重试 |
| 人工快照过期 | 顶部提示；`as_of` 只在广度成功时刷新 |
| 板块快照为演示值 | 计划接 `fetch_sector_flow()` 进 daily |
| 两份目标公式漂移 | 同常量 + node 对拍测试 |
| 缠论被误当结论 | 卡片明写「展示层 · 不改动作」 |
| 日线 900 根上限 | 月线约 41 个月，够 20 月线、不够 60 月 |

优先级：

1. `market.json` 增加分块日期（`blocks_as_of`）；
2. 板块快照接实时并加入 PRODUCTS；
3. 行业权重进 daily（失败 `stale:true`）；
4. daily 前置 `pytest`；
5. 纪律闸门成块、`outlookConflicts()` 接线；
6. 板块技术面；
7. 清理死函数；
8. 缠论 Python/JS 对拍 + A/B。

---

# 附录

## A 常用命令

```bash
bash scripts/daily.sh                     # 每日更新（唯一入口）
SKIP_PULL=1 bash scripts/daily.sh         # 离线调试
POSITIONS_PASSPHRASE='口令' bash scripts/daily.sh

python3 scripts/run_update.py --json      # 只生成
python3 scripts/run_update.py --verify    # 只校验
python3 -m pytest tests -q
node --check src/etfquant/web_assets/app.js
python3 scripts/gen_page_demo.py          # 演示页（不碰线上）
```

## B 字段速查

| 想找 | 字段 |
|---|---|
| 行情日 | `meta.data_date` |
| 快照日 | `meta.snapshot_date` |
| 状态 | `meta.status` |
| 总仓位上限 | `plan.total_target` |
| 单只目标 | `plan.items[].target_weight` |
| 评级/上限 | `plan.items[].grade` / `.cap` |
| 相对强弱 | `legs[].rs.excess5` |
| 行业权重 | `sector_weights.indices[idx][行业]` |
| ETF→指数 | `sector_weights.etf_index[code]` |
| 宽基份额 | `market.national_team.series[-1].groups` |
| 消息解读 | `market.news_sentiment.note` |
| 数据质量 | `packet.data_quality` |

## C 函数索引

| 功能 | 函数 |
|---|---|
| 编排 | `pipeline.run()` / `run_update.main()` |
| 取数 | `loader.daily/spot/index_daily/sector_flow/indices/market` |
| 质量 | `quality.check_bars` / `merge_status` |
| 指标 | `features.frame` / `last_dict` / `indicators.analyze` |
| 规则 | `methodology.load/validate/match_rule/decide` |
| 状态 | `market_regime.classify/compute` / `relative_strength.compute` |
| 目标 | `plan_v3.build` / 前端 `clientSignals` / `synthesizePlanTargets` |
| 价位 | `pricing.prices` / 前端 `orderTicket` |
| 打包 | `packet.build/validate_packet/write` |
| 页面 | `webgen.build_data/render` |
| 前端入口 | `render()` / `page1()` / `page5()` / `page7()` |
| 点评 | `rsBriefSections()` / `rsRenderBrief()` / `webgen._brief` |
| 组合 | `rsSectorExposure()` / `sectorScore()` / `rsRenderSector()` |
| 个股 | `rsRenderDetail()` / `legScore()` / `rsForecast()` / `rsChanOf()` / `rsChanText()` |
| 洞察 | `marketOutlook()` / `buildIdeas()` / `rsRenderReview()` |

## D 术语

| 用 | 不用 |
|---|---|
| 每只持仓 / 这只基金 | 腿、标的、leg |
| 目标仓位表 | 账本、ledger |
| 总仓位上限 | 锚、anchor |
| 评级 | 档位、level |
| 下单信息 | 单据、ticket |
| 数据不足，暂不判断 | ABSTAIN |
| 池外补算 | 临时估算 |
